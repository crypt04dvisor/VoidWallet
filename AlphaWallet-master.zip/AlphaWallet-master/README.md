Alpha Wallet

VERSION 1.1

Work in Progress(Testable)


INSTRUCTIONS


1. CREATE A WALLET.

2. STORE SEED PHRASE IN A SAFE PLACE!

3. LOAD IT WITH A SMALL AMOUNT OF ETH(.0005 IS PLENTY).

4. LOAD IT WITH A SMALL AMOUNT OF THE TOKEN SELECTED IN THE WALLET TO ACTIVATE FUNCTION.


6/10/2019

Test Version Ready!

Added new tokens and integrations as well as a new hyperlink interface.  

Still having some issues with iOS and some browsers, solutions for iOS have been discovered and will be added this year.

Will add marketcap info for token integrations in next the patch.

We will be spending some time community testing the wallet to prepare it for distro.


12/26/2018

Several bug fixes and addition of several features. We will be updating this readme to be more precise soon. Sorry We enjoyed our holidays and forgot to update this =X

11/23/2018 

Added Etherscan Functionability for User Wallets

Adjusted lower limits for gas consumption to require .00025 eth for wallet operation(Down from .00033)



11/17/2018

NOTES

Fund the Wallet with $A and a small amount of ether(.0005 will do) or it will not work correctly

Some browsers do not function well with the use of this Dapp

2fa functions will come soon!

iOS users will gain functionality in the next patch(We hope)

Also for the next patch...Additional ERC20 tokens...Possibly the in-wallet exchange as well

We will be adding a setting to adjust gwei in the next patch as well!

Details.

If you do not have an ERC20 wallet you can create one(Stores all ERC20s)

Gas prices default to the LOWEST settings via the ethereum network


Please note there are no limits in place at this time. We will soon add more complexity to protect our users...but if you enter in incorrect inputs for the Address/Amount This can cause loss of funds!

The Default address is the $A wallet and we do always accept contributions! =)


DEVELOPERS

Contact devdrew@alphaplatform.co for bounties/bug fixes. etc. We reward good ideas!







